---
last-updated: 2026-04-27
review-cycle: 6 months
next-review: 2026-10-27
status: current
---
## 分类体系（前端优先）

### P0 - 前端核心

1. 🖥️ Frontend Frameworks - React, Vue, Angular, Svelte, Solid
2. 🎨 UI Component Libraries - shadcn/ui, Ant Design, MUI, Chakra
3. ⚡ Build Tools - Vite, Webpack, Rollup, esbuild
4. 📊 Data Visualization - D3.js, ECharts, Chart.js, Three.js
5. 🗂️ State Management - Zustand, Redux, Jotai, Pinia
6. 🛣️ Routing - React Router, TanStack Router, Vue Router

### P1 - 工程化

1. 🎭 SSR/Meta Frameworks - Next.js, Nuxt, Remix, Astro
2. 📝 Form Handling - React Hook Form, Formik
3. ✅ Validation - Zod, Yup, Joi
4. 🎨 Styling - Tailwind CSS, Styled Components

### P2 - 后端与工具

1. 🗄️ ORM/Database - Prisma, Drizzle, TypeORM
2. 🧪 Testing - Vitest, Jest, Playwright
3. 🛠️ Linting - ESLint, Prettier, Biome
4. 🔐 Backend - Express, Fastify, NestJS

### 标签体系

- TS支持: 🟢原生 | 🟡类型完善 | 🔴弱类型
- 活跃度: ⭐⭐⭐ | ⭐⭐ | ⭐
- 维护状态: 🟢活跃 | 🟡维护 | 🔴归档
