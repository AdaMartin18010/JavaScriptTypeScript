import React from 'react';
import ReactDOM from 'react-dom/client';
import { TodoProvider } from './context';
import App from './App';
import './style.css';

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('找不到 root 元素');

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <TodoProvider>
      <App />
    </TodoProvider>
  </React.StrictMode>
);
