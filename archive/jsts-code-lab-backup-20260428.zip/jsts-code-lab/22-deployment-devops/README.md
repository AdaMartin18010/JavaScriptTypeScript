﻿# 22-deployment-devops : 部署与 DevOps

> 模块编号: 22-deployment-devops
> 主题: 部署与 DevOps
> 最后更新: 2026-04-27

## 模块概述

本模块深入探讨 **部署与 DevOps**，涵盖核心理论、设计模式与可运行的 TypeScript 代码实现。

CI/CD、容器化、云原生部署流程。通过本模块你将系统掌握从基础概念到工程实践的完整知识体系。

## 核心主题

- CI/CD 流水线
- Docker 容器化
- Kubernetes
- GitOps
- 蓝绿部署

## 文件清单

### TypeScript 代码示例

- **cicd-pipeline.ts** — 可运行示例
- **docker-config.ts** — 可运行示例
- **index.ts** — 可运行示例


## 学习路径

1. 阅读本模块的理论基础文档（如存在 THEORY.md）
2. 逐一运行 TypeScript 代码示例，观察输出行为
3. 修改参数和边界条件，深入理解机制
4. 参考架构设计文档（如存在 ARCHITECTURE.md），理解工程决策

## 相关文档

- [📖 理论基础](./THEORY.md)
- [🏗️ 架构设计](./ARCHITECTURE.md)

---

> 📅 生成日期: 2026-04-27
> 📝 本模块为 JavaScript/TypeScript 全景知识库的代码实验室组成部分
